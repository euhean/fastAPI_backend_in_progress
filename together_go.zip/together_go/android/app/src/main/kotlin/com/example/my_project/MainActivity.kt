package com.manin.togethergo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
